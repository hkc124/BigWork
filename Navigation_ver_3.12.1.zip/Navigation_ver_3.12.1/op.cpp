#include "op.h"
#include "graph.h"
#include <QDebug>
OP::OP(int n, int L ,int W)
{
    G = new Graph(n, L, W);

    Output_Point = new int* [n];
    for (int i = 0; i < n; i++)
    {
        Output_Point_Size++;
        Output_Point[i] = new int[2];
        Output_Point[i][0] = (*G).G[i].X;
        Output_Point[i][1] = (*G).G[i].Y;
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < (int)(*G).G[i].path.size(); j++)
        {
            Output_Path_Size++;
        }
    }
    Output_Path = new int* [Output_Path_Size];
    int Temp = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < (int)(*G).G[i].path.size(); j++)
        {
            Output_Path[Temp] = new int[4];
            Output_Path[Temp][0] = (*G).G[i].X;
            Output_Path[Temp][1] = (*G).G[i].Y;
            Output_Path[Temp][2] = (*G).G[i].path[j].X;
            Output_Path[Temp][3] = (*G).G[i].path[j].Y;
            Temp++;
        }
    }
}
//F1
int OP::Cul_lenth(double X1, int Y1, int X2, int Y2)
{
    return (X1 - X2) * (X1 - X2) + (Y1 - Y2) * (Y1 - Y2);
}
void OP::Release_C()
{
    int Temp = Close_Point_Size;
    Close_Point_Size = 0;
    for (int i = 0; i < Temp; i++)
    {
        delete[] Close_Point[i];
    }
    delete[] Close_Point;

    Temp = Close_Path_Size;
    Close_Path_Size = 0;
    for (int i = 0; i < Temp; i++)
    {
        delete[] Close_Path[i];
    }
    delete[] Close_Path;
}
void OP::F1(int X, int Y)
{
    int C_Size = 0;
    pair<int, int> Close[100];
    for (int i = 0; i < (int)(*G).G.size(); i++)
    {
        int lenth = Cul_lenth(X, Y, (*G).G[i].X, (*G).G[i].Y);
        if (C_Size != 100)
        {
            C_Size++;
            pair<int, int> Temp(lenth, i);
            Close[i] = Temp;
            continue;
        }
        else
        {
            int max = Close[0].first;
            int max_index = 0;//是一百内的索引；
            for (int j = 0; j < 100; j++)
            {
                if (Close[j].first > max)
                {
                    max_index = j;
                    max = Close[j].first;
                }
            }
            if (lenth < Close[max_index].first)
            {
                pair<int, int> Temp(lenth, i);
                Close[max_index] = Temp;
            }
        }
    }
    //以下为释放之前的内存
    Release_C();
    //导出点
    Close_Point_Size = 100;
    Close_Point = new double* [100];
    for (int i = 0; i < 100; i++)
    {
        Close_Point[i] = new double[2];
        Close_Point[i][0] = G->G[Close[i].second].X;
        Close_Point[i][1] = G->G[Close[i].second].Y;
    }
    //导出线
    for (int i = 0; i < 100; i++)
    {
        for (int j = 0; j < (int)G->G[Close[i].second].path.size(); j++)
        {
            Close_Path_Size++;
        }
    }
    Close_Path = new double* [Close_Path_Size];
    int Temp = 0;
    for (int i = 0; i < 100; i++)
    {
        for (int j = 0; j < (int)G->G[Close[i].second].path.size(); j++)
        {
            Close_Path[Temp] = new double[4];
            Close_Path[Temp][0] = G->G[Close[i].second].X;
            Close_Path[Temp][1] = G->G[Close[i].second].Y;
            Close_Path[Temp][2] = G->G[Close[i].second].path[j].X;
            Close_Path[Temp][3] = G->G[Close[i].second].path[j].Y;
            Temp++;
        }
    }
}
