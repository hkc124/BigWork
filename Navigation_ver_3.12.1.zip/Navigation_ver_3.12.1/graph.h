#ifndef GRAPH_H
#define GRAPH_H

#include<iostream>
#include<vector>
#include<map>
#include<ctime>
#include<cstdlib>
#include<utility>
#include "path.h"
#include "point.h"
#include "district.h"
using namespace std;
int random(int i);//随机数,生成的随机数不包括i本身
class Graph
{
public:
    map<pair<int, int>, int> Find;//找到点
    vector<Point> G;//图的组织形式1,顺序组织
    District D_total[10][10];


    //图的内部特性
    int Size = 0;//大小
    //图像素大小,由于区块的原因，尽量为十的倍数
    int X;
    int Y;
    //获得随机值



    //展示函数
    void G_show();
    void print_line(int x, int y);//画点函数

    //区块
    void D_init();//区块初始化
    void D_show();//区块展示
    void District_Donneted();//区块链接函数
    void District_Donneted_Helper(int A1, int B1, int I1, int A2, int B2, int I2);
    //构造函数
    Graph(int n, int x, int y);

};

#endif // GRAPH_H
