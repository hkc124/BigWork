#include "path.h"

Path::Path(int x, int y)
{
    X = x;
    Y = y;
}
