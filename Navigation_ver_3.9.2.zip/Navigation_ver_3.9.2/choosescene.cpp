#include "choosescene.h"
#include <QMenuBar>
#include <QPainter>
#include "mypushbutton.h"
#include <QDebug>
#include <QDialog>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QVBoxLayout>
#include "op.h"
#include <QWheelEvent>

ChooseScene::ChooseScene(QWidget *parent) : QMainWindow(parent),op(10000,1700,750)
{
    //开始配置我们的功能场景(F1-F4)
    this->setFixedSize(1920,1080);
    //设置图标
    this->setWindowIcon(QPixmap(":/photos/001.png"));
    //设置标题
    this->setWindowTitle("Navigation");

    //创建菜单栏
    QMenuBar * bar = menuBar();
    setMenuBar(bar);
    //创建开始菜单
    QMenu * startMenu = bar->addMenu("Start");
    //创建菜单项：退出
    QAction * quitAction = startMenu->addAction("Quit");
    //点击quit退出程序
    connect(quitAction,&QAction::triggered,[=](){
        this->close();
    });

    //返回按钮
    MyPushButton * backBtn = new MyPushButton(":/photos/004.png");
    backBtn->setParent(this);
    backBtn->move(10,880);
    //点击返回
    connect(backBtn,&MyPushButton::clicked,[=](){
        //qDebug() << "返回";
        //发送返回信号
        emit this->chooseSceneBack();
        pointsList.clear();
        pathsList.clear();
    });

    //创建F1-F4按钮
    //1.地图显示：点击F1按钮，输入一个坐标，显示距该点最近的100个点及相关联的边。
    QPushButton *button1 = new QPushButton("地图显示", this); //创建一个按钮
    button1->setStyleSheet("background-color: pink; color: black;"); // 设置按钮的背景颜色和文本颜色
    button1->move(300, 940); //设置按钮的位置
    button1->setFixedSize(300, 80); //设置按钮的固定大小
    // 点击事件槽函数
    connect(button1, &QPushButton::clicked, this, &ChooseScene::addPoint1);


    //2.地图缩放：无需按钮。无输入。鼠标滚轮实现地图缩放。


    //3.最短路径：点击F2按钮，输入两个坐标，显示最短路径。
    QPushButton *button2 = new QPushButton("最短路径", this); //创建一个按钮
    button2->setStyleSheet("background-color: yellow; color: black;"); // 设置按钮的背景颜色和文本颜色
    button2->move(700, 940); //设置按钮的位置
    button2->setFixedSize(300, 80); //设置按钮的固定大小
    // 点击事件槽函数
    connect(button2, &QPushButton::clicked, this, &ChooseScene::addPoint2);


    //4.模拟车流：点击F3按钮，无输入，显示模拟车流。
    QPushButton *button3 = new QPushButton("模拟车流", this); //创建一个按钮
    button3->setStyleSheet("background-color: cyan; color: black;"); // 设置按钮的背景颜色和文本颜色
    button3->move(1100, 940); //设置按钮的位置
    button3->setFixedSize(300, 80); //设置按钮的固定大小
    //connect(button, &QPushButton::clicked, this, &YourClass::showInputDialog); // 连接按钮的点击事件到槽函数
    //模拟车流......?


    //5.最佳路径：点击F4按钮，输入两个坐标，显示最佳路径。
    QPushButton *button4 = new QPushButton("最佳路径", this); //创建一个按钮
    button4->setStyleSheet("background-color: green; color: black;"); // 设置按钮的背景颜色和文本颜色
    button4->move(1500, 940); //设置按钮的位置
    button4->setFixedSize(300, 80); //设置按钮的固定大小
    // 点击事件槽函数
    connect(button4, &QPushButton::clicked, this, &ChooseScene::addPoint4);
}
// 在 ChooseScene 类中添加成员函数 clearData
void ChooseScene::clearData()
{
    pointsList.clear();
    pathsList.clear();
}
void ChooseScene::makePoint(OP op)
{
    for(int i = 0;i < op.Output_Point_Size;i++)
    pointsList.append(QPoint(op.Output_Point[i][0],op.Output_Point[i][1]));
}
void ChooseScene::makeLine(OP op)
{
      for(int i = 0;i < op.Output_Path_Size;i++)
      pathsList.append(QLine(QPoint(op.Output_Path[i][0],op.Output_Path[i][1]),QPoint(op.Output_Path[i][2],op.Output_Path[i][3])));
}
void ChooseScene::showEvent(QShowEvent *event)
{
    QMainWindow::showEvent(event); // 调用基类的 showEvent 函数处理
    clearData(); // 清空数据
    //下面是重新生成
    //op = OP(10000,1700,750);
    makePoint(op); // 重新生成点
    makeLine(op); // 重新生成线
    update(); // 请求更新界面
}
void ChooseScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/photos/002.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);

    // 绘制地图方框
    QRect mapRect(110, 120, 1700, 750); // 假设地图方框在背景图中的位置和大小
    painter.drawRect(mapRect);
    // 绘制白色背景
    painter.fillRect(mapRect, Qt::white);

    for (const auto &point : pointsList)
    {
        // 绘制实心圆点
        int pointSize = 4; // 点的直径大小
        // 设置画刷为红色，填充实心圆
        painter.setBrush(Qt::red);
        painter.setPen(Qt::NoPen); // 不绘制圆形的边框
        painter.drawEllipse(mapRect.x() + point.x() - pointSize/2, mapRect.y() + point.y() - pointSize/2, pointSize, pointSize);
    }


    for (const auto &path : pathsList)
    {
        // 设置画笔颜色和宽度
        painter.setPen(QPen(Qt::black, 1));
        // 绘制线
        painter.drawLine(mapRect.x() + path.p1().x(), mapRect.y() + path.p1().y(), mapRect.x() + path.p2().x(), mapRect.y() +path.p2().y());
    }

    // 绘制新的蓝色点和线
    for (int i = 0; i < op.Close_Point_Size; ++i)
    {
        QPointF point(op.Close_Point[i][0], op.Close_Point[i][1]);
        // 绘制实心圆点
        int pointSize = 4; // 点的直径大小
        // 设置画刷为红色，填充实心圆
        painter.setBrush(Qt::blue);
        painter.setPen(Qt::NoPen); // 不绘制圆形的边框
        painter.drawEllipse(mapRect.x() + point.x() - pointSize/2, mapRect.y() + point.y() - pointSize/2, pointSize, pointSize);
    }

    for (int i = 0; i < op.Close_Path_Size; ++i)
    {
        QLineF path(QPointF(op.Close_Path[i][0], op.Close_Path[i][1]), QPointF(op.Close_Path[i][2], op.Close_Path[i][3]));
        // 设置画笔颜色和宽度
        painter.setPen(QPen(Qt::blue, 1));
        // 绘制线
        painter.drawLine(mapRect.x() + path.p1().x(), mapRect.y() + path.p1().y(), mapRect.x() + path.p2().x(), mapRect.y() +path.p2().y());
    }

}
void ChooseScene::addPoint1()
{
    // 创建对话框
    QDialog dialog(this);
    dialog.setWindowTitle("输入一个坐标，显示距该点最近的100个点及相关联的边");

    // 去掉帮助按钮
    dialog.setWindowFlags(dialog.windowFlags() & ~Qt::WindowContextHelpButtonHint);

    QLabel *label1 = new QLabel("请输入横坐标x:");
    label1->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit1 = new QLineEdit;
    lineEdit1->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label2 = new QLabel("请输入纵坐标y:");
    label2->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit2 = new QLineEdit;
    lineEdit2->setMinimumWidth(1000); // 设置输入框最小宽度

    QPushButton *okButton = new QPushButton("确定");
    okButton->setFixedSize(150, 50); // 设置确定按钮的大小
    connect(okButton, &QPushButton::clicked, &dialog, &QDialog::accept);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(label1);
    layout->addWidget(lineEdit1);
    layout->addWidget(label2);
    layout->addWidget(lineEdit2);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(); // 在确定按钮前加入一个弹簧以实现右对齐
    buttonLayout->addWidget(okButton);
    layout->addLayout(buttonLayout);

    dialog.setLayout(layout);

    // 设置对话框大小
    dialog.resize(1000,300);

    double x, y;
    bool ok = false;

    // 显示对话框并处理结果
    if (dialog.exec() == QDialog::Accepted)
    {
        x = lineEdit1->text().toDouble(&ok);
        if (!ok)
            return;
        y = lineEdit2->text().toDouble(&ok);
        if (!ok)
            return;
    }
    else
    {
        return;
    }
    qDebug() << x;
    qDebug() << y;
    //下面进行地图显示的数据结构与算法......
    //需要用到上文的数据：x是横坐标，y是纵坐标，通过对话框输入
    op.F1(x,y);

    update();
}

//进行地图缩放功能
void ChooseScene::wheelEvent(QWheelEvent *event)
{
    // 获取滚轮滚动的角度，正值表示向前滚动，负值表示向后滚动
    int delta = event->angleDelta().y();

    // 获取鼠标在地图上的位置
    QPointF mousePos = event->pos();

    // 根据滚轮滚动的方向来进行缩放
    if (delta > 0)
    {
        // 向前滚动，放大点和线
        qreal scaleFactor = 1.1;

        for (auto &point : pointsList)
        {
            point.setX((point.x() - mousePos.x()) * scaleFactor + mousePos.x());
            point.setY((point.y() - mousePos.y()) * scaleFactor + mousePos.y());
        }

        for (auto &path : pathsList)
        {
            path.setP1(QPointF((path.p1().x() - mousePos.x()) * scaleFactor + mousePos.x(),
                              (path.p1().y() - mousePos.y()) * scaleFactor + mousePos.y()));
            path.setP2(QPointF((path.p2().x() - mousePos.x()) * scaleFactor + mousePos.x(),
                              (path.p2().y() - mousePos.y()) * scaleFactor + mousePos.y()));
        }
    }
    else if (delta < 0)
    {
        // 向后滚动，缩小点和线
        qreal scaleFactor = 0.9;

        for (auto &point : pointsList)
        {
            point.setX((point.x() - mousePos.x()) * scaleFactor + mousePos.x());
            point.setY((point.y() - mousePos.y()) * scaleFactor + mousePos.y());
        }

        for (auto &path : pathsList)
        {
            path.setP1(QPointF((path.p1().x() - mousePos.x()) * scaleFactor + mousePos.x(),
                              (path.p1().y() - mousePos.y()) * scaleFactor + mousePos.y()));
            path.setP2(QPointF((path.p2().x() - mousePos.x()) * scaleFactor + mousePos.x(),
                              (path.p2().y() - mousePos.y()) * scaleFactor + mousePos.y()));
        }
    }

    // 更新界面
    update();
}



void ChooseScene::addPoint2()
{
    //创建对话框
    QDialog dialog(this);

    dialog.setWindowTitle("输入两个坐标，显示最短路径");

    // 去掉帮助按钮
    dialog.setWindowFlags(dialog.windowFlags() & ~Qt::WindowContextHelpButtonHint);

    QLabel *label1 = new QLabel("请输入第一个坐标的横坐标x1:");
    label1->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit1 = new QLineEdit;
    lineEdit1->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label2 = new QLabel("请输入第一个坐标的纵坐标y1:");
    label2->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit2 = new QLineEdit;
    lineEdit2->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label3 = new QLabel("请输入第二个坐标的横坐标x2:");
    label3->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit3 = new QLineEdit;
    lineEdit3->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label4 = new QLabel("请输入第二个坐标的纵坐标y2:");
    label4->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit4 = new QLineEdit;
    lineEdit4->setMinimumWidth(1000); // 设置输入框最小宽度

    QPushButton *okButton = new QPushButton("确定");
    okButton->setFixedSize(150, 50); // 设置确定按钮的大小
    connect(okButton, &QPushButton::clicked, &dialog, &QDialog::accept);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(label1);
    layout->addWidget(lineEdit1);
    layout->addWidget(label2);
    layout->addWidget(lineEdit2);
    layout->addWidget(label3);
    layout->addWidget(lineEdit3);
    layout->addWidget(label4);
    layout->addWidget(lineEdit4);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(); // 在确定按钮前加入一个弹簧以实现右对齐
    buttonLayout->addWidget(okButton);
    layout->addLayout(buttonLayout);

    dialog.setLayout(layout);

    // 设置对话框大小
    dialog.resize(1000, 550);

    double x1, y1, x2, y2;
    bool ok = false;

    // 显示对话框并处理结果
    if (dialog.exec() == QDialog::Accepted)
    {
        x1 = lineEdit1->text().toDouble(&ok);
        if (!ok)
            return;
        y1 = lineEdit2->text().toDouble(&ok);
        if (!ok)
            return;
        x2 = lineEdit3->text().toDouble(&ok);
        if (!ok)
            return;
        y2 = lineEdit4->text().toDouble(&ok);
        if (!ok)
            return;
    }
    else
    {
        return;
    }
    // 下面进行最短路径的数据结构与算法......
    // 需要用到上文的数据：x1, x2 是横坐标，y1, y2 是纵坐标，通过对话框输入

    // 在这里添加最短路径的计算逻辑

    // 绘制路径等操作...

    // 更新地图或其他显示方式

    // 如果需要更新绘制的点，请取消下面的注释
    pointsList.append(QPoint(x1, y1));
    pointsList.append(QPoint(x2, y2));
    update(); // 调用重绘函数
}
void ChooseScene::addPoint4()
{
    //创建对话框
    QDialog dialog(this);

    dialog.setWindowTitle("输入两个坐标，显示最佳路径");

    // 去掉帮助按钮
    dialog.setWindowFlags(dialog.windowFlags() & ~Qt::WindowContextHelpButtonHint);

    QLabel *label1 = new QLabel("请输入第一个坐标的横坐标x1:");
    label1->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit1 = new QLineEdit;
    lineEdit1->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label2 = new QLabel("请输入第一个坐标的纵坐标y1:");
    label2->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit2 = new QLineEdit;
    lineEdit2->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label3 = new QLabel("请输入第二个坐标的横坐标x2:");
    label3->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit3 = new QLineEdit;
    lineEdit3->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label4 = new QLabel("请输入第二个坐标的纵坐标y2:");
    label4->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit4 = new QLineEdit;
    lineEdit4->setMinimumWidth(1000); // 设置输入框最小宽度

    QPushButton *okButton = new QPushButton("确定");
    okButton->setFixedSize(150, 50); // 设置确定按钮的大小
    connect(okButton, &QPushButton::clicked, &dialog, &QDialog::accept);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(label1);
    layout->addWidget(lineEdit1);
    layout->addWidget(label2);
    layout->addWidget(lineEdit2);
    layout->addWidget(label3);
    layout->addWidget(lineEdit3);
    layout->addWidget(label4);
    layout->addWidget(lineEdit4);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(); // 在确定按钮前加入一个弹簧以实现右对齐
    buttonLayout->addWidget(okButton);
    layout->addLayout(buttonLayout);

    dialog.setLayout(layout);

    // 设置对话框大小
    dialog.resize(1000, 550);

    double x1, y1, x2, y2;
    bool ok = false;

    // 显示对话框并处理结果
    if (dialog.exec() == QDialog::Accepted)
    {
        x1 = lineEdit1->text().toDouble(&ok);
        if (!ok)
            return;
        y1 = lineEdit2->text().toDouble(&ok);
        if (!ok)
            return;
        x2 = lineEdit3->text().toDouble(&ok);
        if (!ok)
            return;
        y2 = lineEdit4->text().toDouble(&ok);
        if (!ok)
            return;
    }
    else
    {
        return;
    }
    // 下面进行最佳路径的数据结构与算法......
    // 需要用到上文的数据：x1, x2 是横坐标，y1, y2 是纵坐标，通过对话框输入

    // 在这里添加最佳路径的计算逻辑

    // 绘制路径等操作...

    // 更新地图或其他显示方式

    // 如果需要更新绘制的点，请取消下面的注释
    pointsList.append(QPoint(x1, y1));
    pointsList.append(QPoint(x2, y2));
    update(); // 调用重绘函数
}
