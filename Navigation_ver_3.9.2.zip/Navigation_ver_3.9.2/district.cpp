#include "district.h"
#include "graph.h"

District::District()
{

}

void District::insert(Point* P)
{
    D_small.push_back(P);
}

int District::max_direction(char C)
{
    if (C == 'F')
    {
        int min = (*D_small[0]).Y;
        int R = 0;
        for (int i = 0; i < int(D_small.size()); i++)
        {
            if ((*D_small[i]).Y < min)
            {
                min = (*D_small[i]).Y;
                R = i;
            }
        }
        return R;
    }
    else if (C == 'B')
    {
        int max = (*D_small[0]).Y;
        int R = 0;
        for (int i = 0; i < int(D_small.size()); i++)
        {
            if ((*D_small[i]).Y > max)
            {

                max = (*D_small[i]).Y;
                R = i;
            }
        }
        return R;
    }
    else if (C == 'L')
    {
        int min = (*D_small[0]).X;
        int R = 0;
        for (int i = 0; i < int(D_small.size()); i++)
        {
            if ((*D_small[i]).X < min)
            {
                min = (*D_small[i]).X;
                R = i;
            }
        }
        return R;
    }
    else if (C == 'R')
    {
        int max = (*D_small[0]).X;
        int R = 0;
        for (int i = 0; i < int(D_small.size()); i++)
        {
            if ((*D_small[i]).X > max)
            {
                max = (*D_small[i]).X;
                R = i;
            }
        }
        return R;
    }
}

int District::Cul(Point I, Point J, Point K)
{
    return (J.X - I.X) * (K.Y - I.Y) - (K.X - I.X) * (J.Y - I.Y);
}

bool District::Judge_Helper(int x1, int y1, int x2, int y2, int a1, int b1, int a2, int b2)//判断两线段是否交叉
{
    bool a = x1 == x2 && y1 == y2;
    bool b = x1 == a1 && y1 == b1;
    bool c = x1 == a2 && y1 == b2;
    bool d = x2 == a1 && y2 == b1;
    bool e = x2 == a2 && y2 == b2;
    bool f = a1 == a2 && b1 == b2;
    if (a || b || c || d || e || f)
    {
        return 0;
    }
    Point A(x1, y1), B(x2, y2), C(a1, b1), D(a2, b2);
    int cross1 = Cul(A, B, C);
    int cross2 = Cul(A, B, D);
    int cross3 = Cul(C, D, A);
    int cross4 = Cul(C, D, B);
    if ((cross1 * cross2 <= 0) && (cross3 * cross4 <= 0)) {
        return true;
    }
    else
    {
        return false;
    }
}
bool District::Judge(Point X, Point Y)//判断是否与现有的路径交叉,返回是否可以建造这个线段
{
    int R;
    if (X.X == Y.X && X.Y == Y.Y)
    {
        return 0;
    }
    for (int i = 0; i < int(D_small.size()); i++)
    {
        for (int j = 0; j < int(D_small[i]->path.size()); j++)
        {
            R = Judge_Helper(X.X, X.Y, Y.X, Y.Y, D_small[i]->X, D_small[i]->Y, D_small[i]->path[j].X, D_small[i]->path[j].Y);
            if (R == 1)
            {
                return 0;
            }
        }
    }
    return 1;
}

void District::Creat(int i, int j)
{
    Path P1(D_small[j]->X, D_small[j]->Y);
    D_small[i]->path.push_back(P1);
    Path P2(D_small[i]->X, D_small[i]->Y);
    D_small[j]->path.push_back(P2);
}

void District::Creat_Paht_Helper(int i)
{
    int R = random(D_small.size());
    int J = Judge(*D_small[i], *D_small[R]);
    while (J != 1)
    {
        R = random(D_small.size());
        J = Judge(*D_small[i], *D_small[R]);
    }
    Creat(i, R);
}

void District::Creat_Path()
{
    if (D_small.size() == 1 || D_small.size() == 0)
    {
        return;
    }
    for (int i = 0; i < int(D_small.size()); i++)
    {
        Creat_Paht_Helper(i);
    }
}
