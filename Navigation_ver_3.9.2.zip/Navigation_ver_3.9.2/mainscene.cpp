#include "mainscene.h"
#include "ui_mainscene.h"
#include <QPainter>
#include "mypushbutton.h"
#include <QDebug>
#include <QTimer>
#include "choosescene.h"
MainScene::MainScene(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainScene)
{
    ui->setupUi(this);

    //配置主场景

    //设置主场景的大小
    setFixedSize(1920,1080);
    //设置图标
    setWindowIcon(QIcon(":/photos/001.png"));
    //设置主标题
    setWindowTitle("Navigation");

    //退出功能实现
    connect(ui->actionQuit,&QAction::triggered,[=](){
        this->close();
    });

    //开始按钮
    MyPushButton * startBtn = new MyPushButton(":/photos/003.png");
    startBtn->setParent(this);
    startBtn->move(80, 200);

    //实例化 点击开始后的场景
    chooseScene = new ChooseScene;

    //监听选择场景的返回信号
    connect(chooseScene,&ChooseScene::chooseSceneBack,this,[=](){
        //延时进入
        QTimer::singleShot(160,this,[=](){
            this->setGeometry(chooseScene->geometry());
            chooseScene->hide();//将选择场景屏蔽
            this->show();//重新显示主场景
        });
    });

    connect(startBtn,&MyPushButton::clicked,[=](){
        //做一个弹起的特效
        startBtn->jumpDown();
        startBtn->jumpUp();

        //延时进入
        QTimer::singleShot(120,this,[=](){
            //进入到选择功能的场景
            //设置chooseScene场景的位置
            chooseScene->setGeometry(this->geometry());
            //自身隐藏、显示下个场景
            this->hide();
            chooseScene->show();
        });

    });
}

void MainScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    //加载背景图片
    pix.load(":/photos/002.jpg");
    //背景图片自适应尺寸
    painter.drawPixmap(0,0,this->width(),this->height(),pix);

    //画背景上的图标（如果需要）
    pix.load(":/photos/005.png");
    //进行缩放比例
    pix = pix.scaled(pix.width()*0.3,pix.height()*0.3);
    //下文的10和30意思是设置该图片的左上角顶点坐标
    painter.drawPixmap(500,80,pix);


}

MainScene::~MainScene()
{
    delete ui;
}

