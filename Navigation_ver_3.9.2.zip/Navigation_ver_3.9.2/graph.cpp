#include"graph.h"
#include<QDebug>
int random(int i)//随机数,生成的随机数不包括i本身
{
    static long long int Seed = 0;//种子
    srand((unsigned)time(NULL) + Seed);
    int R = rand() % i;
    Seed += rand() % 18677;
    return R;
}
//图类，含有各点

void Graph::District_Donneted_Helper(int A1, int B1, int I1, int A2, int B2, int I2)
{
    int X1 = D_total[A1][B1].D_small[I1]->X;
    int Y1 = D_total[A1][B1].D_small[I1]->Y;
    int X2 = D_total[A2][B2].D_small[I2]->X;
    int Y2 = D_total[A2][B2].D_small[I2]->Y;
    D_total[A1][B1].D_small[I1]->insert_P(X2, Y2);
    D_total[A2][B2].D_small[I2]->insert_P(X1, Y1);
}
void Graph::District_Donneted()//区块链接函数
{
    for (int i = 0; i < 9; i++)
    {
        for (int j = 0; j < 9; j++)
        {
            int R = D_total[i][j].max_direction('B');
            int L = D_total[i][j + 1].max_direction('F');
            District_Donneted_Helper(i, j, R, i, j + 1, L);
            int B = D_total[i][j].max_direction('R');
            int F = D_total[i + 1][j].max_direction('L');
            District_Donneted_Helper(i, j, B, i + 1, j, F);
        }
    }
    int R = D_total[9][8].max_direction('B');
    int L = D_total[9][9].max_direction('F');
    District_Donneted_Helper(9, 8, R, 9, 9, L);
    int B = D_total[8][9].max_direction('R');
    int F = D_total[9][9].max_direction('L');
    District_Donneted_Helper(8, 9, B, 9, 9, F);

}

void Graph::D_init()
{
    int X_T = X / 10;
    int Y_T = Y / 10;
    int i = 0;
    int j = 0;;
    for (int n = 0; n < Size; n++)
    {
        i = G[n].X / X_T;
        j = G[n].Y / Y_T;
        D_total[i][j].insert(&G[n]);
    }
    //创建区块内路径
    for (int n = 0; n < 10; n++)
    {
        for (int k = 0; k < 10; k++)
        {
            D_total[n][k].Creat_Path();
        }
    }
    //创建区块链接
    District_Donneted();

}

Graph::Graph(int n, int x, int y)
{
    X = x;
    Y = y;
    for (int i = 0; i <= n; i++)
    {
        Size++;
        int X_temp = random(x);
        int Y_temp = random(y);

        pair<int, int> F(X_temp, Y_temp);
        Find[F] = i;
        Point P(X_temp, Y_temp);
        G.push_back(P);
    }
    //区块初始化
    D_init();

}



