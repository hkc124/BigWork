#ifndef POINT_H
#define POINT_H
#include<vector>
#include"path.h"
using namespace std;
class Point
{
public:
    vector<Path> path;
    int X;
    int Y;
    Point(int x, int y);

    void insert_P(int x, int y);
};

#endif // POINT_H
