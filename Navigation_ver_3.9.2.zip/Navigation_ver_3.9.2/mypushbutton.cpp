#include "mypushbutton.h"
#include <QDebug>
#include <QPropertyAnimation>
//MyPushBotton::MyPushBotton(QWidget *parent) : QPushButton(parent)
//{

//}

MyPushButton::MyPushButton(QString normalImg, QString pressImg)
{
    this->normalImgPath = normalImg;
    this->pressImgPath = pressImg;

    QPixmap pix;
    bool ret = pix.load(normalImg);
    if(!ret)
    {
        return;
    }

    //设置图片固定大小
    this->setFixedSize(pix.width()*0.25,pix.height()*0.25);
    //设置不规则图片格式
    this->setStyleSheet("QPushButton{border:0px}");
    //设置图标
    this->setIcon(pix);
    //设置图标大小
    this->setIconSize(QSize(pix.width()*0.25,pix.height()*0.25));

}

void MyPushButton::jumpDown()//向下跳
{
    //创建动态对象
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");
    //设置动画时间间隔
    animation->setDuration(75);
    //起始位置
    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));
    //结束位置
    animation->setEndValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    //设置弹跳曲线
    animation->setEasingCurve(QEasingCurve::OutBounce);
    //执行动画
    animation->start();
}
void MyPushButton::jumpUp()//向上跳
{
    //创建动态对象
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");
    //设置动画时间间隔
    animation->setDuration(75);
    //起始位置
    animation->setStartValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    //结束位置
    animation->setEndValue(QRect(this->x(),this->y(),this->width(),this->height()));
    //设置弹跳曲线
    animation->setEasingCurve(QEasingCurve::OutBounce);
    //执行动画
    animation->start();
}

//重写按钮 的 按下、释放
void MyPushButton::mousePressEvent(QMouseEvent *e)
{
    if(this->pressImgPath != "")//传入的按下图不为空 说明需要有按下状态
    {
        QPixmap pix;
        bool ret = pix.load(this->pressImgPath);
        if(!ret)
        {
            return;//图片加载失败
        }

        //设置图片固定大小
        this->setFixedSize(pix.width()*0.25,pix.height()*0.25);
        //设置不规则图片格式
        this->setStyleSheet("QPushButton{border:0px}");
        //设置图标
        this->setIcon(pix);
        //设置图标大小
        this->setIconSize(QSize(pix.width()*0.25,pix.height()*0.25));
    }

    //让父类执行其他内容
    return QPushButton::mousePressEvent(e);

}
void MyPushButton::mouseReleaseEvent(QMouseEvent *e)
{
    if(this->pressImgPath != "")//传入的按下图不为空 说明需要有按下状态
    {
        QPixmap pix;
        bool ret = pix.load(this->normalImgPath);
        if(!ret)
        {
            return;//图片加载失败
        }

        //设置图片固定大小
        this->setFixedSize(pix.width()*0.25,pix.height()*0.25);
        //设置不规则图片格式
        this->setStyleSheet("QPushButton{border:0px}");
        //设置图标
        this->setIcon(pix);
        //设置图标大小
        this->setIconSize(QSize(pix.width()*0.25,pix.height()*0.25));
    }

    //让父类执行其他内容
    return QPushButton::mouseReleaseEvent(e);
}
