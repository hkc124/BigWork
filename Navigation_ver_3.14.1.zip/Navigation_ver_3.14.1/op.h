#ifndef OP_H
#define OP_H
#include "graph.h"

class OP
{
public:
    Graph* G;
    int** Output_Point;//点的存储
    int** Output_Path;//线的存储
    int Output_Point_Size = 0;
    int Output_Path_Size = 0;

    //新增内容
    double** Close_Point;
    double** Close_Path;
    int Close_Point_Size = 0;
    int Close_Path_Size = 0;
    int Cul_lenth(double X1, int Y1, int X2, int Y2);
    void Release_C();
    void F1(int X, int Y);

    //以下标形式存储
    OP(int n, int L, int W);
};

#endif // OP_H
