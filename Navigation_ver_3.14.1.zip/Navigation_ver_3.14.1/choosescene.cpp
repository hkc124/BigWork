#include "choosescene.h"
#include <QMenuBar>
#include <QPainter>
#include "mypushbutton.h"
#include <QDebug>
#include <QDialog>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QVBoxLayout>
#include "op.h"
#include <QWheelEvent>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QMouseEvent>
#include <QRect>
#include <QPointF>
#include <QLineF>
#include <QMap>

//前置调用函数

//判断点是否在图中
bool pointInRect(const QPoint &point, const QRect &rect) {
    return rect.contains(point);
}
//找出线与框的交点
QPointF calculateIntersectionPoint(const QPointF& p1, const QPointF& p2, const QRect& rect,int num)
{
    QPointF intersectionPoint;

    QLineF line(p1, p2);

    // 获取矩形的四个顶点
    QPointF topLeft(rect.topLeft());
    QPointF topRight(rect.topRight());
    QPointF bottomLeft(rect.bottomLeft());
    QPointF bottomRight(rect.bottomRight());

    // 检查线段与矩形的四条边是否相交
    QList<QLineF> edges;
    edges << QLineF(topLeft, topRight)
          << QLineF(topRight, bottomRight)
          << QLineF(bottomRight, bottomLeft)
          << QLineF(bottomLeft, topLeft);

    for (const QLineF& edge : edges)
    {
        if (line.intersects(edge, &intersectionPoint) == QLineF::BoundedIntersection)
        {
            if(num==1)
                return intersectionPoint;
            else
            {
                num--;
            }
        }
    }

    // 如果线段未与任何边相交，说明交点就是p1
    return p1;
}
bool operator<(const QPoint& p1, const QPoint& p2)//重载<,不然会报错，因为键值是QPoint
{
    if (p1.x() == p2.x()) {
        return p1.y() < p2.y();
    }
    return p1.x() < p2.x();
}
void ChooseScene::updateViewPoints(QVector<PointF>& points,QRect mapRect)
{
    //改变显示状态
    for (auto &point : points)
    {
        QPoint pointAsQPoint(point.x(), point.y());
        if (pointInRect(pointAsQPoint, mapRect))//如果点在框内
        {
            //视为可见
            point.visible = true;
        }
        else point.visible = false;//点在框外，视为不可见
    }
}
void ChooseScene::updateViewPaths(QVector<LineF>& paths,QRect mapRect)
{
    //最后改变显示状态
    for (auto &path : paths)
    {
        QPoint point1(path.p1().x(), path.p1().y());
        QPoint point2(path.p2().x(), path.p2().y());
        if(pointInRect(point1,mapRect)&&pointInRect(point2,mapRect))//完全在框内
        {
            path.visible = true;//视为可见
        }
        else if(pointInRect(point1,mapRect)||pointInRect(point2,mapRect))
        {
            //计算线与框的交点
            QPointF intersectionPoint;
            if (pointInRect(point1, mapRect))
            {
                intersectionPoint = calculateIntersectionPoint(path.p1(), path.p2(), mapRect, 1);
                path.setP2(intersectionPoint);
            }
            else
            {
                intersectionPoint = calculateIntersectionPoint(path.p2(), path.p1(), mapRect, 1);
                path.setP1(intersectionPoint);
            }
            path.visible = true;//视为可见
        }
        else
        {
            //即使两端点都不在框内，它们之间的线段也可能在框内
            //尝试寻找
            QPointF intersectionPoint1 = calculateIntersectionPoint(path.p1(), path.p2(), mapRect, 1);
            QPointF intersectionPoint2 = calculateIntersectionPoint(path.p2(), path.p1(), mapRect, 2);
            if(intersectionPoint1!=path.p1()||intersectionPoint2!=path.p2())
            {
                path.setP1(intersectionPoint1);
                path.setP2(intersectionPoint2);
                path.visible = true;//视为可见
            }
            else
                path.visible = false;//视为不可见
        }
    }
}
void ChooseScene::updateRepresentativePoints(QVector<PointF>& points)
{
    //存储质心点
    QMap<QPoint, Grid> gridCenters;//第一个为键值，第二个为value
    //接下来进行质心算法
    for (auto &point : points)
    {
        // 将点的坐标转换为网格坐标
        int gridX = point.x() / 20;
        int gridY = point.y() / 20;
        QPoint gridIndex(gridX, gridY);

        // 更新或添加网格内的质心点
        if (!gridCenters.contains(gridIndex))
        {
            Grid grid;
            grid.center = point.pos;
            grid.count = 1; // 初始为1，包含当前点
            gridCenters[gridIndex] = grid;
        }
        else
        {
            // 更新质心点为网格内所有点的平均值
            Grid& grid = gridCenters[gridIndex];
            QPointF currentCenter = grid.center;
            QPointF newCenter = currentCenter;
            newCenter.setX((currentCenter.x() * grid.count + point.x()) / (grid.count + 1));
            newCenter.setY((currentCenter.y() * grid.count + point.y()) / (grid.count + 1));
            grid.center = newCenter;
            grid.count++;
        }
    }
    //清空points，points接下来来准备存储各质心点
    points.clear();
    for (const auto &center : gridCenters)
    {
        points.append(center.center);
    }


}
void ChooseScene::updateRepresentativePaths(QVector<LineF>& paths)
{
    //思路：path=paths[hash]
    //用键值来存储
    //首先先定义一个QMap，遍历所有点，求出每个网格的质心点存储在QMap中
    //接着遍历每一条线，判断各线两端点处在哪个网格里，再调用paths[hash]将质心覆盖原来的两端点值于path中
    //存储质心点
    QMap<QPoint, Grid> gridCenters;//第一个为键值，第二个为value
    QVector<PointF> points;
    for (auto &path : paths)
    {
        points.append(path.p1());
        points.append(path.p2());
    }
    for (auto &point : points)
    {
        // 将点的坐标转换为网格坐标
        int gridX = point.x() / 20;
        int gridY = point.y() / 20;
        QPoint gridIndex(gridX, gridY);

        // 更新或添加网格内的质心点
        if (!gridCenters.contains(gridIndex))
        {
            Grid grid;
            grid.center = point.pos;
            grid.count = 1; // 初始为1，包含当前点
            gridCenters[gridIndex] = grid;
        }
        else
        {
            // 更新质心点为网格内所有点的平均值
            Grid grid = gridCenters[gridIndex];
            QPointF currentCenter = grid.center;
            QPointF newCenter = currentCenter;
            newCenter.setX((currentCenter.x() * grid.count + point.x()) / (grid.count + 1));
            newCenter.setY((currentCenter.y() * grid.count + point.y()) / (grid.count + 1));
            grid.center = newCenter;
            grid.count++;
            gridCenters[gridIndex] = grid;
        }
    }
    for (auto &path : paths)
    {
        int gridX1 = path.p1().x() / 20;
        int gridY1 = path.p1().y() / 20;
        int gridX2 = path.p2().x() / 20;
        int gridY2 = path.p2().y() / 20;
        QPoint gridIndex1(gridX1, gridY1);
        QPoint gridIndex2(gridX2, gridY2);
        path.setP1(gridCenters[gridIndex1].center);
        path.setP2(gridCenters[gridIndex2].center);
    }


}

//构造函数
ChooseScene::ChooseScene(QWidget *parent) : QMainWindow(parent),op(10000,1700,750)
{
    //开始配置我们的功能场景(F1-F4)
    this->setFixedSize(1920,1080);
    //设置图标
    this->setWindowIcon(QPixmap(":/photos/001.png"));
    //设置标题
    this->setWindowTitle("Navigation");

    //创建菜单栏
    QMenuBar * bar = menuBar();
    setMenuBar(bar);
    //创建开始菜单
    QMenu * startMenu = bar->addMenu("Start");
    //创建菜单项：退出
    QAction * quitAction = startMenu->addAction("Quit");
    //点击quit退出程序
    connect(quitAction,&QAction::triggered,[=](){
        this->close();
    });

    //返回按钮
    MyPushButton * backBtn = new MyPushButton(":/photos/004.png");
    backBtn->setParent(this);
    backBtn->move(10,880);
    //点击返回
    connect(backBtn,&MyPushButton::clicked,[=](){
        //qDebug() << "返回";
        //发送返回信号
        emit this->chooseSceneBack();
        pointsList.clear();
        pathsList.clear();
    });

    //创建F1-F4按钮
    //1.地图显示：点击F1按钮，输入一个坐标，显示距该点最近的100个点及相关联的边。
    QPushButton *button1 = new QPushButton("地图显示", this); //创建一个按钮
    button1->setStyleSheet("background-color: pink; color: black;"); // 设置按钮的背景颜色和文本颜色
    button1->move(300, 940); //设置按钮的位置
    button1->setFixedSize(300, 80); //设置按钮的固定大小
    // 点击事件槽函数
    connect(button1, &QPushButton::clicked, this, &ChooseScene::addPoint1);


    //2.地图缩放：无需按钮。无输入。鼠标滚轮实现地图缩放。


    //3.最短路径：点击F2按钮，输入两个坐标，显示最短路径。
    QPushButton *button2 = new QPushButton("最短路径", this); //创建一个按钮
    button2->setStyleSheet("background-color: yellow; color: black;"); // 设置按钮的背景颜色和文本颜色
    button2->move(700, 940); //设置按钮的位置
    button2->setFixedSize(300, 80); //设置按钮的固定大小
    // 点击事件槽函数
    connect(button2, &QPushButton::clicked, this, &ChooseScene::addPoint2);


    //4.模拟车流：点击F3按钮，无输入，显示模拟车流。
    QPushButton *button3 = new QPushButton("模拟车流", this); //创建一个按钮
    button3->setStyleSheet("background-color: cyan; color: black;"); // 设置按钮的背景颜色和文本颜色
    button3->move(1100, 940); //设置按钮的位置
    button3->setFixedSize(300, 80); //设置按钮的固定大小
    //connect(button, &QPushButton::clicked, this, &YourClass::showInputDialog); // 连接按钮的点击事件到槽函数
    //模拟车流......?


    //5.最佳路径：点击F4按钮，输入两个坐标，显示最佳路径。
    QPushButton *button4 = new QPushButton("最佳路径", this); //创建一个按钮
    button4->setStyleSheet("background-color: green; color: black;"); // 设置按钮的背景颜色和文本颜色
    button4->move(1500, 940); //设置按钮的位置
    button4->setFixedSize(300, 80); //设置按钮的固定大小
    // 点击事件槽函数
    connect(button4, &QPushButton::clicked, this, &ChooseScene::addPoint4);
}
// 在 ChooseScene 类中添加成员函数 clearData
void ChooseScene::clearData()
{
    pointsList.clear();
    pathsList.clear();
}
void ChooseScene::makePoint()
{
    for(int i = 0;i < op.Output_Point_Size;i++)
    pointsList.append(PointF(QPointF(op.Output_Point[i][0],op.Output_Point[i][1])));
    tempPointsList1 = pointsList;//备份数据
    updateRepresentativePoints(pointsList);
}
void ChooseScene::makeLine()
{
    for(int i = 0;i < op.Output_Path_Size;i++)
    pathsList.append(LineF(QPointF(op.Output_Path[i][0],op.Output_Path[i][1]),QPointF(op.Output_Path[i][2],op.Output_Path[i][3])));
    tempPathsList1 = pathsList;
    updateRepresentativePaths(pathsList);
    ClusterPathsList1 = pathsList;
}
void ChooseScene::makeClosePoint()
{
    close_pointsList.clear();
    for(int i = 0;i < op.Close_Point_Size;i++)
    close_pointsList.append(PointF(QPointF(op.Close_Point[i][0],op.Close_Point[i][1])));
    tempPointsList2 = close_pointsList;
    updateRepresentativePoints(close_pointsList);
}
void ChooseScene::makeCloseLine()
{
    close_pathsList.clear();
    for(int i = 0;i < op.Close_Path_Size;i++)
    close_pathsList.append(LineF(QPointF(op.Close_Path[i][0],op.Close_Path[i][1]),QPointF(op.Close_Path[i][2],op.Close_Path[i][3])));
    tempPathsList2 = close_pathsList;
    updateRepresentativePaths(close_pathsList);
    ClusterPathsList2 = close_pathsList;
}
void ChooseScene::showEvent(QShowEvent *event)
{
    QMainWindow::showEvent(event); // 调用基类的 showEvent 函数处理
    clearData(); // 清空数据
    //下面是重新生成
    //op = OP(10000,1700,750);
    makePoint(); // 重新生成点
    makeLine(); // 重新生成线
    update(); // 请求更新界面
}
void ChooseScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/photos/002.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);

    // 绘制地图方框
    QRect mapRect(110, 120, 1700, 750); // 假设地图方框在背景图中的位置和大小
    painter.drawRect(mapRect);
    // 绘制白色背景
    painter.fillRect(mapRect, Qt::white);

    for (auto &point : pointsList)
    {
        if(point.visible)
        {
            // 绘制实心圆点
            int pointSize = 4; // 点的直径大小
            // 设置画刷为红色，填充实心圆
            painter.setBrush(Qt::red);
            painter.setPen(Qt::NoPen); // 不绘制圆形的边框
            painter.drawEllipse(mapRect.x() + point.pos.x() - pointSize/2, mapRect.y() + point.pos.y() - pointSize/2, pointSize, pointSize);
        }
    }


    for (auto &path : pathsList)
    {
        if(path.visible)
        {
            // 设置画笔颜色和宽度
            painter.setPen(QPen(Qt::black, 1));
            // 绘制线
            painter.drawLine(mapRect.x() + path.p1().x(), mapRect.y() + path.p1().y(), mapRect.x() + path.p2().x(), mapRect.y() +path.p2().y());
        }
    }

    // 绘制新的蓝色点和线
    for (auto &point : close_pointsList)
    {
        if(point.visible)
        {
            // 绘制实心圆点
            int pointSize = 4; // 点的直径大小
            // 设置画刷为红色，填充实心圆
            painter.setBrush(Qt::blue);
            painter.setPen(Qt::NoPen); // 不绘制圆形的边框
            painter.drawEllipse(mapRect.x() + point.pos.x() - pointSize/2, mapRect.y() + point.pos.y() - pointSize/2, pointSize, pointSize);
        }
    }

    for (auto &path : close_pathsList)
    {
        if(path.visible)
        {
            // 设置画笔颜色和宽度
            painter.setPen(QPen(Qt::blue, 1));
            // 绘制线
            painter.drawLine(mapRect.x() + path.p1().x(), mapRect.y() + path.p1().y(), mapRect.x() + path.p2().x(), mapRect.y() +path.p2().y());
        }
    }
}
void ChooseScene::addPoint1()
{
    // 创建对话框
    QDialog dialog(this);
    dialog.setWindowTitle("输入一个坐标，显示距该点最近的100个点及相关联的边");

    // 去掉帮助按钮
    dialog.setWindowFlags(dialog.windowFlags() & ~Qt::WindowContextHelpButtonHint);

    QLabel *label1 = new QLabel("请输入横坐标x:");
    label1->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit1 = new QLineEdit;
    lineEdit1->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label2 = new QLabel("请输入纵坐标y:");
    label2->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit2 = new QLineEdit;
    lineEdit2->setMinimumWidth(1000); // 设置输入框最小宽度

    QPushButton *okButton = new QPushButton("确定");
    okButton->setFixedSize(150, 50); // 设置确定按钮的大小
    connect(okButton, &QPushButton::clicked, &dialog, &QDialog::accept);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(label1);
    layout->addWidget(lineEdit1);
    layout->addWidget(label2);
    layout->addWidget(lineEdit2);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(); // 在确定按钮前加入一个弹簧以实现右对齐
    buttonLayout->addWidget(okButton);
    layout->addLayout(buttonLayout);

    dialog.setLayout(layout);

    // 设置对话框大小
    dialog.resize(1000,300);

    double x, y;
    bool ok = false;

    // 显示对话框并处理结果
    if (dialog.exec() == QDialog::Accepted)
    {
        x = lineEdit1->text().toDouble(&ok);
        if (!ok)
            return;
        y = lineEdit2->text().toDouble(&ok);
        if (!ok)
            return;
    }
    else
    {
        return;
    }
    //下面进行地图显示的数据结构与算法......
    //需要用到上文的数据：x是横坐标，y是纵坐标，通过对话框输入
    op.F1(x,y);
    makeClosePoint();
    makeCloseLine();
    update();
}
//进行地图缩放功能
void ChooseScene::wheelEvent(QWheelEvent *event)
{
    QRect mapRect(0, 0, 1700, 750);

    // 获取滚轮滚动的角度，正值表示向前滚动，负值表示向后滚动
    int delta = event->angleDelta().y();

    // 获取鼠标在地图上的位置
    QPointF mousePos = event->posF();
    qreal scaleFactor;
    // 根据滚轮滚动的方向来进行缩放
    if (delta > 0) scaleFactor = 1.25;
    else if (delta < 0) scaleFactor = 0.8;

    //1.数据配置的点
    for (auto &point : tempPointsList1)
    {
        point.setX((110+point.x() - mousePos.x()) * scaleFactor + mousePos.x()-110);
        point.setY((120+point.y() - mousePos.y()) * scaleFactor + mousePos.y()-120);
    }
    pointsList = tempPointsList1;
    updateRepresentativePoints(pointsList);//取质心点
    updateViewPoints(pointsList,mapRect);


    //2.数据配置的线
    pathsList = tempPathsList1;//恢复数据
    for (auto &path : pathsList)
    {
        path.setP1(QPointF((110+path.p1().x() - mousePos.x()) * scaleFactor + mousePos.x()-110,
                          (120+path.p1().y() - mousePos.y()) * scaleFactor + mousePos.y()-120));
        path.setP2(QPointF((110+path.p2().x() - mousePos.x()) * scaleFactor + mousePos.x()-110,
                          (120+path.p2().y() - mousePos.y()) * scaleFactor + mousePos.y()-120));
    }
    tempPathsList1 = pathsList;
    updateRepresentativePaths(pathsList);//取质心点
    ClusterPathsList1 = pathsList;
    updateViewPaths(pathsList,mapRect);

    //3.F1的点
    for (auto &point : tempPointsList2)
    {
        point.setX((110+point.x() - mousePos.x()) * scaleFactor + mousePos.x()-110);
        point.setY((120+point.y() - mousePos.y()) * scaleFactor + mousePos.y()-120);
    }
    close_pointsList = tempPointsList2;
    updateRepresentativePoints(close_pointsList);//取质心点
    updateViewPoints(close_pointsList,mapRect);

    //4.F1的线
    close_pathsList = tempPathsList2;
    for (auto &path : close_pathsList)
    {
        path.setP1(QPointF((110+path.p1().x() - mousePos.x()) * scaleFactor + mousePos.x()-110,
                          (120+path.p1().y() - mousePos.y()) * scaleFactor + mousePos.y()-120));
        path.setP2(QPointF((110+path.p2().x() - mousePos.x()) * scaleFactor + mousePos.x()-110,
                          (120+path.p2().y() - mousePos.y()) * scaleFactor + mousePos.y()-120));
    }
    tempPathsList2 = close_pathsList;
    updateRepresentativePaths(close_pathsList);//取质心点
    ClusterPathsList2 = close_pathsList;
    updateViewPaths(close_pathsList,mapRect);

    // 更新界面
    update();

}
//鼠标拖拽功能
void ChooseScene::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        // 记录下鼠标按下时的位置
        lastMousePos = event->pos();
    }
}
void ChooseScene::mouseMoveEvent(QMouseEvent *event)
{
    //2024.3.14
    //这里的输入接口得改为当前的聚类状态
    QRect mapRect(0, 0, 1700, 750);

    if (event->buttons() & Qt::LeftButton) {
        // 计算鼠标移动的距离
        QPointF delta = event->pos() - lastMousePos;

        // 更新地图上的点和路径的位置
        //1
        for (auto &point : tempPointsList1) {
            point.pos += delta;
        }
        for (auto &point : pointsList) {
            point.pos += delta;
        }
        updateViewPoints(pointsList,mapRect);

        //2
        pathsList = ClusterPathsList1;//恢复数据
        for (auto &path : tempPathsList1) {
            path.translate(delta);
        }
        for (auto &path : pathsList) {
            path.translate(delta);
        }
        ClusterPathsList1 = pathsList;//备份数据
        updateViewPaths(pathsList,mapRect);

        //3
        for (auto &point : tempPointsList2) {
            point.pos += delta;
        }
        for (auto &point : close_pointsList) {
            point.pos += delta;
        }
        updateViewPoints(close_pointsList,mapRect);

        //4
        close_pathsList = ClusterPathsList2;//恢复数据
        for (auto &path : tempPathsList2) {
            path.translate(delta);
        }
        for (auto &path : close_pathsList) {
            path.translate(delta);
        }
        ClusterPathsList2 = close_pathsList;//备份数据
        updateViewPaths(close_pathsList,mapRect);


        // 更新界面
        update();

        // 更新 lastMousePos
        lastMousePos = event->pos();
    }
}
void ChooseScene::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        // 清空 lastMousePos
        lastMousePos = QPointF();
    }
}


void ChooseScene::addPoint2()
{
    //创建对话框
    QDialog dialog(this);

    dialog.setWindowTitle("输入两个坐标，显示最短路径");

    // 去掉帮助按钮
    dialog.setWindowFlags(dialog.windowFlags() & ~Qt::WindowContextHelpButtonHint);

    QLabel *label1 = new QLabel("请输入第一个坐标的横坐标x1:");
    label1->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit1 = new QLineEdit;
    lineEdit1->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label2 = new QLabel("请输入第一个坐标的纵坐标y1:");
    label2->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit2 = new QLineEdit;
    lineEdit2->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label3 = new QLabel("请输入第二个坐标的横坐标x2:");
    label3->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit3 = new QLineEdit;
    lineEdit3->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label4 = new QLabel("请输入第二个坐标的纵坐标y2:");
    label4->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit4 = new QLineEdit;
    lineEdit4->setMinimumWidth(1000); // 设置输入框最小宽度

    QPushButton *okButton = new QPushButton("确定");
    okButton->setFixedSize(150, 50); // 设置确定按钮的大小
    connect(okButton, &QPushButton::clicked, &dialog, &QDialog::accept);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(label1);
    layout->addWidget(lineEdit1);
    layout->addWidget(label2);
    layout->addWidget(lineEdit2);
    layout->addWidget(label3);
    layout->addWidget(lineEdit3);
    layout->addWidget(label4);
    layout->addWidget(lineEdit4);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(); // 在确定按钮前加入一个弹簧以实现右对齐
    buttonLayout->addWidget(okButton);
    layout->addLayout(buttonLayout);

    dialog.setLayout(layout);

    // 设置对话框大小
    dialog.resize(1000, 550);

    double x1, y1, x2, y2;
    bool ok = false;

    // 显示对话框并处理结果
    if (dialog.exec() == QDialog::Accepted)
    {
        x1 = lineEdit1->text().toDouble(&ok);
        if (!ok)
            return;
        y1 = lineEdit2->text().toDouble(&ok);
        if (!ok)
            return;
        x2 = lineEdit3->text().toDouble(&ok);
        if (!ok)
            return;
        y2 = lineEdit4->text().toDouble(&ok);
        if (!ok)
            return;
    }
    else
    {
        return;
    }
    // 下面进行最短路径的数据结构与算法......
    // 需要用到上文的数据：x1, x2 是横坐标，y1, y2 是纵坐标，通过对话框输入

    // 在这里添加最短路径的计算逻辑

    // 绘制路径等操作...

    // 更新地图或其他显示方式

    // 如果需要更新绘制的点，请取消下面的注释
    //pointsList.append(QPoint(x1, y1));
    //pointsList.append(QPoint(x2, y2));
    update(); // 调用重绘函数
}
void ChooseScene::addPoint4()
{
    //创建对话框
    QDialog dialog(this);

    dialog.setWindowTitle("输入两个坐标，显示最佳路径");

    // 去掉帮助按钮
    dialog.setWindowFlags(dialog.windowFlags() & ~Qt::WindowContextHelpButtonHint);

    QLabel *label1 = new QLabel("请输入第一个坐标的横坐标x1:");
    label1->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit1 = new QLineEdit;
    lineEdit1->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label2 = new QLabel("请输入第一个坐标的纵坐标y1:");
    label2->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit2 = new QLineEdit;
    lineEdit2->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label3 = new QLabel("请输入第二个坐标的横坐标x2:");
    label3->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit3 = new QLineEdit;
    lineEdit3->setMinimumWidth(1000); // 设置输入框最小宽度

    QLabel *label4 = new QLabel("请输入第二个坐标的纵坐标y2:");
    label4->setStyleSheet("font-size: 28px;"); // 设置标签字体大小
    QLineEdit *lineEdit4 = new QLineEdit;
    lineEdit4->setMinimumWidth(1000); // 设置输入框最小宽度

    QPushButton *okButton = new QPushButton("确定");
    okButton->setFixedSize(150, 50); // 设置确定按钮的大小
    connect(okButton, &QPushButton::clicked, &dialog, &QDialog::accept);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(label1);
    layout->addWidget(lineEdit1);
    layout->addWidget(label2);
    layout->addWidget(lineEdit2);
    layout->addWidget(label3);
    layout->addWidget(lineEdit3);
    layout->addWidget(label4);
    layout->addWidget(lineEdit4);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(); // 在确定按钮前加入一个弹簧以实现右对齐
    buttonLayout->addWidget(okButton);
    layout->addLayout(buttonLayout);

    dialog.setLayout(layout);

    // 设置对话框大小
    dialog.resize(1000, 550);

    double x1, y1, x2, y2;
    bool ok = false;

    // 显示对话框并处理结果
    if (dialog.exec() == QDialog::Accepted)
    {
        x1 = lineEdit1->text().toDouble(&ok);
        if (!ok)
            return;
        y1 = lineEdit2->text().toDouble(&ok);
        if (!ok)
            return;
        x2 = lineEdit3->text().toDouble(&ok);
        if (!ok)
            return;
        y2 = lineEdit4->text().toDouble(&ok);
        if (!ok)
            return;
    }
    else
    {
        return;
    }
    // 下面进行最佳路径的数据结构与算法......
    // 需要用到上文的数据：x1, x2 是横坐标，y1, y2 是纵坐标，通过对话框输入

    // 在这里添加最佳路径的计算逻辑

    // 绘制路径等操作...

    // 更新地图或其他显示方式

    // 如果需要更新绘制的点，请取消下面的注释
    //pointsList.append(QPoint(x1, y1));
    //pointsList.append(QPoint(x2, y2));
    update(); // 调用重绘函数
}
