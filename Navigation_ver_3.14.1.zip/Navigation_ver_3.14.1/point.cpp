#include "point.h"
#include "path.h"
Point::Point(int x, int y)
{
    X = x;
    Y = y;
}

void Point::insert_P(int x, int y)
{
    Path P(x, y);
    path.push_back(P);
}
