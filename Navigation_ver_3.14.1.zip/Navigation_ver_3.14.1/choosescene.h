#ifndef CHOOSESCENE_H
#define CHOOSESCENE_H

#include <QMainWindow>
#include "op.h"
class PointF {
public:
    QPointF pos;
    bool visible;

    PointF(QPointF position) : pos(position), visible(true) {}
    double x() { return pos.x();}
    double y() { return pos.y();}
    void setX(double x){ pos.setX(x);}
    void setY(double y){ pos.setY(y);}
};

class LineF {
public:
    QPointF startPos;
    QPointF endPos;
    bool visible;

    LineF(QPointF start, QPointF end) : startPos(start), endPos(end), visible(true) {}
    void setP1(QPointF q){startPos = q;}
    void setP2(QPointF q){endPos = q;}
    QPointF p1(){return startPos;}
    QPointF p2(){return endPos;}
    void translate(QPointF q){startPos += q;endPos += q;}

};
// 定义网格类
class Grid {
public:
    QPointF center;
    int count;

    Grid() : count(0) {}
};

class ChooseScene : public QMainWindow
{
    Q_OBJECT
public:
    explicit ChooseScene(QWidget *parent = nullptr);

    //重写绘图事件
    void paintEvent(QPaintEvent *);

    //重写显示界面
    void showEvent(QShowEvent *event);

    void clearData();

    //在地图上添加点
    void addPoint1();

    //更新代表点和线
    void updateRepresentativePoints(QVector<PointF>& points);
    void updateRepresentativePaths(QVector<LineF>& paths);
    void updateViewPoints(QVector<PointF>& points,QRect mapRect);
    void updateViewPaths(QVector<LineF>& paths,QRect mapRect);
    //地图缩放
    void wheelEvent(QWheelEvent *event);
    //鼠标拖拽
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);

    void addPoint2();
    void addPoint4();

    //转换点和线的存储结构
    void makePoint();
    void makeLine();
    void makeClosePoint();
    void makeCloseLine();

signals:
    //写一个自定义信号，告诉主场景 点击了返回
    void chooseSceneBack();

private:
    //用于保存输出值，它的最终结果等于聚类值
    QVector<PointF> pointsList;
    QVector<LineF> pathsList;
    QVector<PointF> close_pointsList;
    QVector<LineF> close_pathsList;

    OP op;
    QPointF lastMousePos; // 用于保存鼠标按下时的位置

    //用于保存原始值，原始值作为放缩的输入
    QVector<PointF> tempPointsList1;
    QVector<LineF> tempPathsList1;
    QVector<PointF> tempPointsList2;
    QVector<LineF> tempPathsList2;


    //用于保存聚类值，聚类值作为拖拽的输入
//    QVector<PointF> ClusterPointsList1;
    QVector<LineF> ClusterPathsList1;
//    QVector<PointF> ClusterPointsList2;
    QVector<LineF> ClusterPathsList2;
};

#endif // CHOOSESCENE_H
