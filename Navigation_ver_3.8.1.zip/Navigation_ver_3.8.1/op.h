#ifndef OP_H
#define OP_H
#include "graph.h"

class OP
{
public:
    Graph* G;
    int** Output_Point;//点的存储
    int** Output_Path;//线的存储
    int Output_Point_Size = 0;
    int Output_Path_Size = 0;
    //以下标形式存储
    OP(int n, int L, int W);
};

#endif // OP_H
