#include "op.h"
#include "graph.h"
#include <QDebug>
OP::OP(int n, int L ,int W)
{
    G = new Graph(n, L, W);

    Output_Point = new int* [n];
    for (int i = 0; i < n; i++)
    {
        Output_Point_Size++;
        Output_Point[i] = new int[2];
        Output_Point[i][0] = (*G).G[i].X;
        Output_Point[i][1] = (*G).G[i].Y;
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < (int)(*G).G[i].path.size(); j++)
        {
            Output_Path_Size++;
        }
    }
    Output_Path = new int* [Output_Path_Size];
    int Temp = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < (int)(*G).G[i].path.size(); j++)
        {
            Output_Path[Temp] = new int[4];
            Output_Path[Temp][0] = (*G).G[i].X;
            Output_Path[Temp][1] = (*G).G[i].Y;
            Output_Path[Temp][2] = (*G).G[i].path[j].X;
            Output_Path[Temp][3] = (*G).G[i].path[j].Y;
            Temp++;
        }
        }
}

