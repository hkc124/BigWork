#ifndef DISTRICT_H
#define DISTRICT_H
#include<vector>
#include "point.h"
using namespace std;

class District
{
public:
    vector<Point*> D_small;//记录数据的地址

    District();
    void insert(Point* P);

    int max_direction(char C);

    int Cul(Point I, Point J, Point K);

    bool Judge_Helper(int x1, int y1, int x2, int y2, int a1, int b1, int a2, int b2);//判断两线段是否交叉

    bool Judge(Point X, Point Y);//判断是否与现有的路径交叉,返回是否可以建造这个线段

    void Creat(int i, int j);

    void Creat_Paht_Helper(int i);

    void Creat_Path();


};

#endif // DISTRICT_H
