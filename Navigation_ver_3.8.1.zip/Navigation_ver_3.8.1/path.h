#ifndef PATH_H
#define PATH_H


class Path
{
public:
    Path(int x, int y);
    int X;
    int Y;

};

#endif // PATH_H
