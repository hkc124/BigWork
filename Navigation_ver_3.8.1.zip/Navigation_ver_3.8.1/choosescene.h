#ifndef CHOOSESCENE_H
#define CHOOSESCENE_H

#include <QMainWindow>
#include "op.h"

class ChooseScene : public QMainWindow
{
    Q_OBJECT
public:
    explicit ChooseScene(QWidget *parent = nullptr);

    //重写绘图事件
    void paintEvent(QPaintEvent *);

    //在地图上添加点
    void addPoint1();
    void addPoint2();
    void addPoint4();

    //转换点和线的存储结构
    void makePoint(OP op);
    void makeLine(OP op);

signals:
    //写一个自定义信号，告诉主场景 点击了返回
    void chooseSceneBack();

private:
    QList<QPointF> pointsList;
    QList<QLine> pathsList;


};

#endif // CHOOSESCENE_H
